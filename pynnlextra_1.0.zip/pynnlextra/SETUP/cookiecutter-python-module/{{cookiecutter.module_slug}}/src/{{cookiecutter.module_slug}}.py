"""
Module documentation...
"""
def sample_function():
    """
    Sample function documentation...
    """
    print("sample {{cookiecutter.module_slug}} function")

class {{cookiecutter.module_slug | title}}:
    """
    Class documentation...
    """

    def sample_method(self):
        """
        Sample method documentation...
        """
        print("sample {{cookiecutter.module_slug | title}} instance method")
